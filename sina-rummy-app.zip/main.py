        # Sina Rummy - Minimal Kivy prototype (login + local pass-and-play)
        # This is a small prototype app to run on desktop/mobile with Kivy.
        # It's not a final APK. Use buildozer to build to Android.
        from kivy.app import App
        from kivy.uix.boxlayout import BoxLayout
        from kivy.uix.label import Label
        from kivy.uix.button import Button
        from kivy.uix.textinput import TextInput
        from kivy.core.window import Window

        class LoginScreen(BoxLayout):
            def __init__(self, on_login, **kwargs):
                super().__init__(**kwargs)
                self.orientation = 'vertical'
                self.padding = 20
                self.spacing = 10
                self.add_widget(Label(text='Sina Rummy', font_size=32, size_hint=(1,0.2)))
                self.name_input = TextInput(hint_text='Enter your name', size_hint=(1,0.15))
                self.add_widget(self.name_input)
                self.status = Label(text='', size_hint=(1,0.1))
                self.add_widget(self.status)
                btn = Button(text='Login', size_hint=(1,0.15))
                btn.bind(on_release=lambda *_: on_login(self.name_input.text))
                self.add_widget(btn)

        class LobbyScreen(BoxLayout):
            def __init__(self, player_name, start_local_game, **kwargs):
                super().__init__(**kwargs)
                self.orientation = 'vertical'
                self.padding = 10
                self.spacing = 10
                self.player_name = player_name
                self.add_widget(Label(text=f'Welcome, {player_name}', size_hint=(1,0.1)))
                self.add_widget(Label(text='Lobby (prototype)', size_hint=(1,0.1)))
                btn1 = Button(text='Start Pass-and-Play (2 players)', size_hint=(1,0.15))
                btn1.bind(on_release=lambda *_: start_local_game())
                self.add_widget(btn1)
                self.add_widget(Label(text='(Online multiplayer will be implemented in server version)', size_hint=(1,0.6)))

        class GameScreen(BoxLayout):
            def __init__(self, on_back, **kwargs):
                super().__init__(**kwargs)
                self.orientation = 'vertical'
                self.padding = 10
                self.spacing = 10
                self.add_widget(Label(text='Pass-and-Play Prototype', size_hint=(1,0.1)))
                self.turn_label = Label(text='Player 1 turn', size_hint=(1,0.1))
                self.add_widget(self.turn_label)
                self.info = Label(text='This prototype does local play only.
Use it to test UI on device.', size_hint=(1,0.3))
                self.add_widget(self.info)
                btn_next = Button(text='End Turn (Pass Device)', size_hint=(1,0.15))
                btn_next.bind(on_release=self.next_turn)
                self.add_widget(btn_next)
                btn_back = Button(text='Back to Lobby', size_hint=(1,0.15))
                btn_back.bind(on_release=lambda *_: on_back())
                self.add_widget(btn_back)
                self.turn = 1

            def next_turn(self, *a):
                self.turn = 2 if self.turn == 1 else 1
                self.turn_label.text = f'Player {self.turn} turn'

        class SinaRummyApp(App):
            def build(self):
                Window.size = (360, 640)
                self.root = BoxLayout()
                self.show_login()
                return self.root

            def show_login(self):
                self.root.clear_widgets()
                self.login = LoginScreen(self.on_login)
                self.root.add_widget(self.login)

            def on_login(self, name):
                name = name.strip() or 'Player'
                self.player_name = name
                self.show_lobby()

            def show_lobby(self):
                self.root.clear_widgets()
                self.lobby = LobbyScreen(self.player_name, self.start_local_game)
                self.root.add_widget(self.lobby)

            def start_local_game(self):
                self.root.clear_widgets()
                self.game = GameScreen(self.show_lobby)
                self.root.add_widget(self.game)

        if __name__ == '__main__':
            SinaRummyApp().run()
