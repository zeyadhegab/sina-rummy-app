# Sina Rummy - Prototype (sina-rummy-app)

This repository contains a minimal Kivy prototype for *Sina Rummy* (login + pass-and-play).
It is a starting point for the Android app.

## What is included
- `main.py`: Minimal Kivy application with Login, Lobby, and Pass-and-Play prototype.
- `buildozer.spec`: Example buildozer spec for building an APK.
- `.github/workflows/` folder with an example workflow (instructions below).
- `assets/icon.png`: placeholder app icon.

## How to run locally (desktop)
1. Install Python 3.8+ and Kivy:
   ```bash
   python -m pip install kivy
   ```
2. Run:
   ```bash
   python main.py
   ```

## How to build APK (recommended: use WSL2 / Ubuntu)
1. Install dependencies as documented in Buildozer docs.
2. Install `buildozer` in WSL/Ubuntu and run:
   ```bash
   buildozer -v android debug
   ```
3. The generated APK will be in `bin/` folder.

## GitHub Actions
Building Kivy APKs on GitHub Actions requires a Linux environment with system packages.
You can use a prebuilt action or self-hosted runner. Because environment differences are common,
it's recommended to build locally first.

-- End of prototype README --
